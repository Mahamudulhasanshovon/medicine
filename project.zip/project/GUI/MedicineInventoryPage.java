package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entity.Medicine;
import EntityList.*;
import File.FileIO;

public class MedicineInventoryPage extends JFrame implements ActionListener {
    Font titleFont = new Font("cambria", Font.BOLD, 30);
    Font font15 = new Font("cambria", Font.BOLD, 15);
    Font font20 = new Font("cambria", Font.BOLD, 20);

    JTextField idTextField, nameTextField, manufacturerTextField, typeTextField, stockTextField;
    JTextField searchTextField, deleteTextField;
    JTextArea display;

    JButton addButton, updateButton, searchButton, deleteButton, clearButton, showAllButton;
    MedicineList medicineList = new MedicineList(100);

    public MedicineInventoryPage() {
        super("Medicine Management GUI");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(940, 650); 
        this.setLocation(150, 0);
        this.getContentPane().setBackground(new Color(218, 232, 252));
        this.setLayout(null);

        // =========== DEMO DATA =================
       FileIO.loadMedicinesFromFile(medicineList);

        JLabel title = new JLabel("Medicine Management System");
        title.setBounds(230, 10, 500, 50); 
        title.setFont(titleFont);

        JLabel subTitle = new JLabel("MEDICINE INFORMATIONS");
        subTitle.setBounds(300, 60, 320, 50); 
        subTitle.setFont(new Font("Cambria", Font.BOLD, 25));
        int top = 100;
        int gap = 40;

        JLabel idLabel = new JLabel("Medicine ID");
        idLabel.setBounds(20, top, 200, 30); 
        idLabel.setFont(font15);

        idTextField = new JTextField();
        idTextField.setBounds(20, top += gap, 200, 30);
        idTextField.setFont(font15);

        JLabel nameLabel = new JLabel("Medicine Name");
        nameLabel.setBounds(20, top += gap, 200, 30);
        nameLabel.setFont(font15);

        nameTextField = new JTextField();
        nameTextField.setBounds(20, top += gap, 200, 30); 
        nameTextField.setFont(font15);

        JLabel manufacturerLabel = new JLabel("Manufacturer");
        manufacturerLabel.setBounds(20, top += gap, 200, 30);
        manufacturerLabel.setFont(font15);

        manufacturerTextField = new JTextField();
        manufacturerTextField.setBounds(20, top += gap, 200, 30);
        manufacturerTextField.setFont(font15);

        JLabel typeLabel = new JLabel("Medicine Type");
        typeLabel.setBounds(20, top += gap, 200, 30);
        typeLabel.setFont(font15);

        typeTextField = new JTextField();
        typeTextField.setBounds(20, top += gap, 200, 30);
        typeTextField.setFont(font15);

        JLabel stockLabel = new JLabel("Stock Available");
        stockLabel.setBounds(20, top += gap, 200, 30); 
        stockLabel.setFont(font15);

        stockTextField = new JTextField();
        stockTextField.setBounds(20, top += gap, 200, 30);
        stockTextField.setFont(font15);

        addButton = new JButton("ADD");
        addButton.setBounds(20, top += gap + 20, 200, 30);
        addButton.setBackground(Color.GREEN);
        addButton.setFont(font15);
        addButton.addActionListener(this);

        updateButton = new JButton("UPDATE");
        updateButton.setBounds(20, top += gap, 200, 30);
        updateButton.setBackground(Color.BLUE);
        updateButton.setForeground(Color.WHITE);
        updateButton.setFont(font15);
        updateButton.addActionListener(this);

        top = 100;
        gap = 40;

        JLabel searchLabel = new JLabel("Search By Medicine ID");
        searchLabel.setBounds(700, top, 200, 30);
        searchLabel.setFont(font15);

        searchTextField = new JTextField();
        searchTextField.setBounds(700, top += gap, 200, 30);
        searchTextField.setFont(font15);

        searchButton = new JButton("SEARCH");
        searchButton.setBounds(700, top += gap, 200, 30);
        searchButton.setBackground(Color.YELLOW);
        searchButton.setFont(font15);
        searchButton.addActionListener(this);

        JLabel deleteLabel = new JLabel("Delete By Medicine ID");
        deleteLabel.setBounds(700, top += gap, 200, 30);
        deleteLabel.setFont(font15);

        deleteTextField = new JTextField();
        deleteTextField.setBounds(700, top += gap, 200, 30);
        deleteTextField.setFont(font15);

        deleteButton = new JButton("DELETE");
        deleteButton.setBounds(700, top += gap, 200, 30);
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFont(font15);
        deleteButton.addActionListener(this);

        showAllButton = new JButton("SHOW ALL");
        showAllButton.setBounds(700, 500, 200, 30);
        showAllButton.setBackground(Color.PINK);
        showAllButton.setForeground(Color.WHITE);
        showAllButton.setFont(font15);
        showAllButton.addActionListener(this);

        clearButton = new JButton("CLEAR SCREEN");
        clearButton.setBounds(700, 550, 200, 30);
        clearButton.setBackground(Color.DARK_GRAY);
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(font15);
        clearButton.addActionListener(this);

        display = new JTextArea();
        display.setFont(font20);
        JScrollPane jsp = new JScrollPane(display);
        jsp.setBounds(250, 100, 400, 500);
        this.add(jsp);

        reloadData();

        // ================= ADD ALL THE COMPONENTS TO CONTAINER ====================== //
        this.add(title);
        this.add(subTitle);
        this.add(idLabel);
        this.add(idTextField);
        this.add(nameLabel);
        this.add(nameTextField);
        this.add(manufacturerLabel);
        this.add(manufacturerTextField);
        this.add(typeLabel);
        this.add(typeTextField);
        this.add(stockLabel);
        this.add(stockTextField);
        this.add(addButton);
        this.add(updateButton);
        this.add(searchLabel);
        this.add(searchTextField);
        this.add(searchButton);
        this.add(deleteLabel);
        this.add(deleteTextField);
        this.add(deleteButton);
        this.add(clearButton);
        this.add(showAllButton);

        // ================= DISPLAY THE FRAME ====================== //
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (addButton == e.getSource()) {
            System.out.println("ADD CLICKED");
            if (medicineList.getById(idTextField.getText()) == null) {
                if (!idTextField.getText().isEmpty() &&
                    !nameTextField.getText().isEmpty() &&
                    !manufacturerTextField.getText().isEmpty() &&
                    !typeTextField.getText().isEmpty() &&
                    !stockTextField.getText().isEmpty()) {
                    
                    Medicine m = new Medicine(idTextField.getText(),
                                               nameTextField.getText(),
                                               manufacturerTextField.getText(),
                                               typeTextField.getText(),
                                               Integer.parseInt(stockTextField.getText()));
                    medicineList.insert(m);
                    reloadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Please Provide All Information", "Missing Data", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "ID Already Used", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (updateButton == e.getSource()) {
			
            System.out.println("UPDATE CLICKED");
			
        } else if (searchButton == e.getSource()) {
			
            System.out.println("SEARCH CLICKED");
			
            Medicine m = medicineList.getById(searchTextField.getText());
            if (m != null) {
                display.setText(m.getMedicineAsString());
            } else {
                JOptionPane.showMessageDialog(this, "No Medicine Found with this ID");
            }
        } else if (deleteButton == e.getSource()) {
            System.out.println("DELETE CLICKED");
            Medicine m = medicineList.getById(deleteTextField.getText());
            if (m != null) {
                medicineList.removeById(deleteTextField.getText());
                reloadData();
            } else {
				
                JOptionPane.showMessageDialog(this, "No Medicine Found with this ID", "Error", JOptionPane.WARNING_MESSAGE);
            }
			
        } else if (showAllButton == e.getSource()) {
			
            System.out.println("SHOW ALL CLICKED");
            reloadData();
		
        } else if (clearButton == e.getSource()) {  
		
            System.out.println("CLEAR CLICKED");
        }
    }

    public void reloadData() {
        display.setText(medicineList.getAllMedicinesAsString());
    }
}
