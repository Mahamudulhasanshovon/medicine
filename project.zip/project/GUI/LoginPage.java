package GUI;
import javax.swing.*; // JFrame, JLabel, JTextField, JButton
import java.awt.*; // Font, Color
import java.awt.event.*;
import File.FileIO;

public class LoginPage extends JFrame implements ActionListener, MouseListener {
    JLabel userLabel, passLabel;
    JTextField userField;
    JPasswordField passField;
    JButton loginBtn, registerBtn;

    Font font20 = new Font("cambria", Font.BOLD, 20);
    Font font25 = new Font("cambria", Font.BOLD, 25);
    Font font30 = new Font("cambria", Font.BOLD, 30);

    public LoginPage() {
        super("Login Page");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 400); // w,h
        this.setLocation(300, 100); // x,y
        this.setLayout(null);

        // User Name Label
        userLabel = new JLabel("User Name");
        userLabel.setBounds(100, 30, 200, 30); // x,y,w,h
        userLabel.setFont(font25);
        this.add(userLabel);

        // User Name TextField
        userField = new JTextField();
        userField.setBounds(100, 70, 200, 30); // x,y,w,h
        userField.setFont(font25);
        userField.setBackground(new Color(31, 242, 149));
        this.add(userField);

        // Password Label
        passLabel = new JLabel("User Password");
        passLabel.setBounds(100, 110, 200, 30); // x,y,w,h
        passLabel.setFont(font25);
        this.add(passLabel);

        // Password Field
        passField = new JPasswordField();
        passField.setEchoChar('*');
        passField.setBounds(100, 150, 200, 30); // x,y,w,h
        passField.setFont(font25);
        passField.setBackground(new Color(31, 242, 149));
        this.add(passField);

        // Login Button
        loginBtn = new JButton("Login");
        loginBtn.setBounds(100, 200, 200, 30);
        loginBtn.setFont(font25);
        loginBtn.setBackground(Color.BLUE);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.addActionListener(this);
        loginBtn.addMouseListener(this);
        this.add(loginBtn);

        // Register Button
        registerBtn = new JButton("Register");
        registerBtn.setBounds(100, 240, 200, 30);
        registerBtn.setFont(font25);
        registerBtn.setBackground(new Color(200, 200, 150));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.addActionListener(this);
        this.add(registerBtn);

        this.setVisible(true);
    }

    public void mouseEntered(MouseEvent e) {
        if (e.getSource() == loginBtn) {
            loginBtn.setBackground(Color.RED);
            loginBtn.setForeground(Color.WHITE);
        }
    }

    public void mouseExited(MouseEvent e) {
        if (e.getSource() == loginBtn) {
            loginBtn.setBackground(Color.BLUE);
            loginBtn.setForeground(Color.WHITE);
        }
    }

    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginBtn) {
			
            String userName = userField.getText();
            String userPassword = String.valueOf(passField.getPassword());

            if(FileIO.checkUser(userName,userPassword)){
				JOptionPane.showMessageDialog(this,"User Verified");
				MedicineInventoryPage minv = new MedicineInventoryPage();
				this.setVisible(false);
          
            } else {
                JOptionPane.showMessageDialog(this, "User Name or Password Mismatch", "Invalid User", JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == registerBtn) {
            JOptionPane.showMessageDialog(this, "Register Button Pressed", "Register", JOptionPane.WARNING_MESSAGE);
        
        }
    }
}
