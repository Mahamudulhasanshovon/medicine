package File;
import java.io.*;
import java.util.Scanner;
import Entity.*;
import EntityList.*;

public class FileIO {
    public static boolean checkUser(String userName, String userPass) {
        boolean flag = false;
        try {
            Scanner fsc = new Scanner(new File("./File/users.txt"));
            while (fsc.hasNextLine()) {
                String line = fsc.nextLine();
                String data[] = line.split(";");
                if (userName.equals(data[1]) && userPass.equals(data[2])) {
                    flag = true;
                    break;
                }
            }
            fsc.close();
        } catch (Exception ex) {
            System.out.println("Cannot Read File");
        }
        return flag;
    }

    public static void loadMedicinesFromFile(MedicineList medicineList) {
        try {
            Scanner fsc = new Scanner(new File("./File/medicines.txt"));
            while (fsc.hasNextLine()) {
                String line = fsc.nextLine();
                String data[] = line.split(";");
                Medicine m = new Medicine(data[0], data[1], data[2], data[3], Integer.parseInt(data[4]));
                medicineList.insert(m);
            }
            fsc.close();
        } catch (Exception ex) {
            System.out.println("Cannot Read File");
        }
    }

    public static void writeMedicineInFile(Medicine m) {
        try {
            FileWriter fw = new FileWriter(new File("./File/medicines.txt"), true);
            String line = m.getMedicineId() + ";" + m.getMedicineName() + ";" +
                          m.getMedicineManufacturer() + ";" + m.getMedicineType() + ";" +
                          m.getMedicineStock() + "\n";
            fw.write(line);
            fw.flush();
            fw.close();
        } catch (Exception ex) {
            System.out.println("File Not Found");
        }
    }
}