import Entity.Medicine;
import EntityList.MedicineList;
import GUI.*;

public class Start {
    public static void main(String[] args) {
        MedicineList medicineList = new MedicineList(10);
        medicineList.insert(new Medicine("1", "Paracetamol", "Acetaminophen", "Tablet", 100));
        medicineList.insert(new Medicine("2", "Ibuprofen", "Ibuprofen", "Tablet", 50));
        medicineList.insert(new Medicine("3", "Aspirin", "Acetylsalicylic Acid", "Tablet", 75));
        medicineList.insert(new Medicine("4", "Amoxicillin", "Amoxicillin", "Capsule", 30));
        medicineList.insert(new Medicine("5", "Lisinopril", "Lisinopril", "Tablet", 60));

        // medicineList.showAll();
        
        medicineList.getById("2").setMedicineName("Updated Amoxicillin");
        medicineList.removeById("1");
        medicineList.showAll();

        LoginPage loginPage = new LoginPage();
    }
}
