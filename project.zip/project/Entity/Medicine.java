package Entity;

public class Medicine {
    private String medicineId;
    private String medicineName;
    private String medicineManufacturer;
    private String medicineType;
    private int medicineStock;

    private static int medicineCounter = 0;

    public Medicine() {}

    public Medicine(String medicineId, String medicineName, String medicineManufacturer, String medicineType, int medicineStock) {
        this.medicineId = medicineId;
        this.medicineName = medicineName;
        this.medicineManufacturer = medicineManufacturer;
        this.medicineType = medicineType;
        this.medicineStock = medicineStock;
        medicineCounter++;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public void setMedicineManufacturer(String medicineManufacturer) {
        this.medicineManufacturer = medicineManufacturer;
    }

    public void setMedicineId(String medicineId) {
        this.medicineId = medicineId;
    }

    public void setMedicineType(String medicineType) {
        this.medicineType = medicineType;
    }

    public void setMedicineStock(int medicineStock) {
        this.medicineStock = medicineStock;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getMedicineManufacturer() {
        return medicineManufacturer;
    }

    public String getMedicineId() {
        return medicineId;
    }

    public int getMedicineStock() {
        return medicineStock;
    }

    public String getMedicineType() {
        return medicineType;
    }

    public void showMedicineInfo() {
        System.out.println("Medicine Id : " + medicineId);
        System.out.println("Medicine Name : " + medicineName);
        System.out.println("Medicine Manufacturer : " + medicineManufacturer);
        System.out.println("Medicine Type : " + medicineType);
        System.out.println("Stock Available : " + medicineStock);
    }

    public String getMedicineAsString() {
        return "Medicine Id : " + medicineId + "\n" +
               "Medicine Name : " + medicineName + "\n" +
               "Medicine Manufacturer : " + medicineManufacturer + "\n" +
               "Medicine Type : " + medicineType + "\n" +
               "Stock Available : " + medicineStock;
    }

    public void addMedicineStock(int x) {
        medicineStock += x;
    }

    public static void totalNumberOfUniqueMedicines() {
        System.out.println("Total Number Of Unique Medicines : " + medicineCounter);
    }
}
