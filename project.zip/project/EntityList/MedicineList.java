package EntityList;
import Entity.Medicine;
public class MedicineList {
    private Medicine medicines[];
    public MedicineList() {
        medicines = new Medicine[5];
    }

    public MedicineList(int size) {
        medicines = new Medicine[size];
    }

    public void insert(Medicine m) {
        boolean flag = false;
        for (int i = 0; i < medicines.length; i++) {
            if (medicines[i] == null) {
                medicines[i] = m;
                flag = true;
                break;
            }
        }

        if (flag) {
            System.out.println("Successfully Inserted.");
        } else {
            System.out.println("Insertion Failed.");
        }
    }

    public Medicine getById(String id) {
        boolean flag = false;
        Medicine m = null;
        for (int i = 0; i < medicines.length; i++) {
            if (medicines[i] != null) {
                if (medicines[i].getMedicineId().equals(id)) {
                    m = medicines[i];
                    flag = true;
                    break;
                }
            }
        }
        if (flag) {
            System.out.println("Medicine found.");
        } else {
            System.out.println("Medicine not found.");
        }
        return m;
    }

    public void removeById(String id) {
        boolean flag = false;
        for (int i = 0; i < medicines.length; i++) {
            if (medicines[i] != null) {
                if (medicines[i].getMedicineId().equals(id)) {
                    medicines[i] = null;
                    flag = true;
                    break;
                }
            }
        }
        if (flag) {
            System.out.println("Medicine Removed.");
        } else {
            System.out.println("Medicine not found with this id.");
        }
    }

    public void showAll() {
        for (int i = 0; i < medicines.length; i++) {
            if (medicines[i] != null) {
                System.out.println("-------------");
                medicines[i].showMedicineInfo();
                System.out.println("-------------");
            }
        }
    }

    public String getAllMedicinesAsString() {
        String allMedicines = "";
        for (int i = 0; i < medicines.length; i++) {
            if (medicines[i] != null) {
                allMedicines += "-------------" + "\n" +
                                medicines[i].getMedicineAsString() + "\n" +
                                "-------------" + "\n";
            }
        }
        return allMedicines;
    }
}
